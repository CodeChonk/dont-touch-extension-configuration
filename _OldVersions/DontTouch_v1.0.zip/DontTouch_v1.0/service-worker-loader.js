//const allowedURLs = ["com", "net", "edu", "gov", "org"];
const blockUrl = chrome.runtime.getURL("/assets/blocked.html");

//listener waits for tab to be updated to execute
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  //const currentUrl = tab.url;       // non url object for tld determination
  const thisUrl = new URL(tab.url); // url object for protocol determination
  //console.log("Current URL: ", thisUrl.href);
  //console.log("Current protocol: ", thisUrl.protocol);
  //console.log("Current is allowed: ", isUrlAllowed(thisUrl));

  //ensures present tab
  if (thisUrl) {
    
  //confines function to blocking extension pages
      if (thisUrl.protocol == "chrome-extension:") {

  // if url not allowed redirect current tab to block page
       if (!isUrlAllowed(thisUrl)) {chrome.tabs.update(tabId, { url: blockUrl });}
     }
    
  }

});

//function takes top level domain from url and compares it to the list of those allowed
function isUrlAllowed(url) {
    if (url.pathname.includes("setting") || url.pathname.includes("config") || url.pathname.includes("option")) {return false;}
    else {return true;}
}

/*
function extractTopLevelDomain(url) {
    try {
  // Create a URL object to parse the input
      const parsedUrl = new URL(url);
      
  // Normalize the hostname (remove www. if present)
      const hostname = parsedUrl.hostname.replace(/^www\./, '');
      
  // Split the hostname into parts
      const parts = hostname.split('.');
      
  // common multi-part TLDs 

      const tldRules = [
        { suffix: '.co.uk' },
        { suffix: '.com.au' },
        { suffix: '.org.uk' },
        { suffix: '.co' },
        { suffix: '.org' },
        { suffix: '.net' },
        { suffix: '.com' },
        { suffix: '.edu' }
      ];
      
      // Check for multi-part TLDs first
      for (const rule of tldRules) {
        if (hostname.endsWith(rule.suffix)) {
          // Return the full suffix
          return rule.suffix.replace(/^\./, '');
        }
      }
      
      // simple TLD extraction
      // Take the last part of the hostname
      return parts[parts.length - 1];
    } catch (error) {
      // Handle invalid URLs
      console.error('Invalid URL:', error);
      return null;
    }
  }
*/