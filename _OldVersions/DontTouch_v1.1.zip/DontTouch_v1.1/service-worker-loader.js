const blockUrl = chrome.runtime.getURL("/assets/blocked.html");

//listener waits for tab to be updated to execute
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const thisUrl = new URL(tab.url); // url object for protocol determination

  if (thisUrl) { //ensures present tab
    if (thisUrl.protocol == "chrome-extension:") {  //confines function to blocking extension pages
       if (!isUrlAllowed(thisUrl)) {chrome.tabs.update(tabId, { url: blockUrl });}   // if url not allowed redirect current tab to block page
     }
  }
});

//function searches url for disallowed patterns
function isUrlAllowed(url) {
    if (url.href.includes("setting") || url.href.includes("config") || url.href.includes("option")) {return false;}
    else {return true;}
}
